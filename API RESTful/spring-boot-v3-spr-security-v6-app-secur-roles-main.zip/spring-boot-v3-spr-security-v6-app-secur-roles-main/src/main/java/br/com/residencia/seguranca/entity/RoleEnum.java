package br.com.residencia.seguranca.entity;

public enum RoleEnum {
	ROLE_USER,
	ROLE_MODERATOR,
	ROLE_ADMIN
}